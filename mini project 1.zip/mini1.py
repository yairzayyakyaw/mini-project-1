#! C:\Python36\python.exe
import cgi
import cgitb;cgitb.enable()

print("Content-type:text/html\n\n")

print("""
<html>
<head>


</head>
<body>

<form name='testform' action="register.py" method="post">
  <div class="container">
    <h1>Register</h1>
    <hr>
	<label for="firstname"><b>Firstname</b></label>
    <input type="text" placeholder="Enter Firtname" name="firstname" required><br><br>
	
	<label for="lastname"><b>Lastname</b></label>
    <input type="text" placeholder="Enter Lastname" name="lastname" required><br><br>
	
    <label for="email"><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="email" required><br><br>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required><br><br>
    <hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>

    <input type="hidden" name="submitted" value="1">
    <button type="submit" class="registerbtn">Register</button>
  </div>
</form>
</body>
</html>

""")
